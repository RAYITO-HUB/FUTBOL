const botonMostrarImagen = document.getElementById('mostrarImagen');
const contenedorImagen = document.getElementById('contenedorImagen');

botonMostrarImagen.addEventListener('click', function() {
    if (contenedorImagen.style.display === 'none') {
        contenedorImagen.style.display = 'block';
        botonMostrarImagen.style.display = "none";
    }
});

contenedorImagen.onclick = () => {

  contenedorImagen.style.display = 'none';
  botonMostrarImagen.style.display = "block";

}